package voting;

public class User {

		private String name;
		private String nid;
		private String fathername;
		private String mothername;
		private String address;
		
		
		public User(String name,String nid,String fathername,String mothername,String address){
			this.name = name;
			this.nid = nid;
			this.fathername=fathername;
			this.mothername=mothername;
			this.address = address;
		}
		
		public String getName() {
			return name;
		}
		public void setName(String name) {
			this.name = name;
		}
		public String getnid() {
			return nid;
		}
		public void setnid(String nid) {
			this.nid = nid;
		}
			public String getfathername() {
				return fathername;
			}
			public void setfathername(String fathername) {
				this.fathername = fathername;
		}
			
			public String getmotherame() {
				return mothername;
			}
			public void mothername(String mothername) {
				this.mothername = mothername;
			}
				
		public String getAddress() {
			return address;
		}
		public void setAddress(String address) {
			this.address = address;
		}

		@Override
		public String toString() {
			return     "Name:"+ name + "\n" +
		               "NID:"+ nid + "\n" +
		               "Father's name:"+ fathername + "\n" +
		               "Mother's name:"+mothername + "\n" +
		               "Address:"+address+ "\n";
		
		}	
		
	}


