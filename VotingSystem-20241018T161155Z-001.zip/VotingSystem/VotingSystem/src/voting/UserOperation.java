package voting;

	import java.util.List;
	import java.util.Scanner;
	import java.util.Set;

	public class UserOperation {
		
		public void registration(VoterList voterList) {
			Scanner scanner = new Scanner(System.in);
			
			System.out.print("\nPlease enter your name:");
			String name = scanner.nextLine();
			
			System.out.print("Please enter NID:");
			String nid = scanner.nextLine();
		
			
			System.out.print("Please enter your father's name:");
			String fathername = scanner.nextLine();
			
			
			System.out.print("Please enter your mother's name:");
			String mothername = scanner.nextLine();
		
			
			System.out.print("Please enter your address:");
			String address = scanner.nextLine();
			
			User user = new User(name,nid,fathername,mothername,address);
			 System.out.println("\n\nContact added successfully.\n\n");

		
			//System.out.println(user);

			voterList.setVoterList(user);
			voterList.totalVoter();
			System.out.println();	
		}
		
		public void takeVote(VoterList voterList, Set<User> voted, List<Integer> count,Result result) 
		{
			Scanner scanner = new Scanner(System.in);
			System.out.print("\nPlease enter your Nid number:");
			
			String nid = scanner.nextLine();

		
			
			User user = voterList.findUser(nid);
			if(user == null) {
				System.out.println("\nPlease Register first\n");
				return;
			}
			
			int prevSize = voted.size();
			voted.add(user);
			if(prevSize == voted.size()) {
				System.out.println("\nYou have taken, try next year\n");
				return;
			}
			System.out.println("Give your Vote:");
			System.out.println("1.A");
			System.out.println("2.B");
			System.out.println("3.C");
			//System.out.println(user);
			int v = scanner.nextInt();
			if (v >= 1 && v <= 3) {
		        count.add(v);
		        result.addVote(v);
		        System.out.println("\nVote recorded.\n");
		    } else {
		        System.out.println("\nInvalid candidate selection. Please vote for A, B, or C.");
		    }
		
		}

}
