/*Make a e-voting system for the people's Republic of Bangladesh.
 *  The system has the capabilities to take vote but not more than
 *   one and can calculate the results of individual candidate.
 *    Make at least 3 candidates for this system.
 */
package voting;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Scanner;
import java.util.Set;

public class main {

	public static void main(String[] args) {
		
				System.out.println("===============");
				System.out.println("Welcome to EVM");
				System.out.println("===============");
         		System.out.println("");
				
				VoterList voterList = new VoterList();
				UserOperation userOperation = new UserOperation();
				Set<User> voted = new HashSet<>();
				List<Integer> count = new ArrayList<>();
				 Result result = new Result();
				
				while(true) {
					Scanner scanner = new Scanner(System.in);
					System.out.println("1.Registration");
					System.out.println("2.Vote");
					System.out.println("3.Result");
				    System.out.println("0.Exit\n");
					
					
					System.out.print("\nEnter your choice:");
					int choice = scanner.nextInt();

					
				

					switch(choice)
					{
					
					
					case 1:
						userOperation.registration(voterList);
					    break;
					    
					    case 2:
					
						userOperation.takeVote(voterList,voted,count,result);
					break;
					case 3:
					 {
					  
		             result.displayResults();
					
					break;
					 }
				  
					default:
					{
						System.out.println("Please enter a valid choice.\n");
					}
					}
				}
	}
}
				
				
				
			
				
				
