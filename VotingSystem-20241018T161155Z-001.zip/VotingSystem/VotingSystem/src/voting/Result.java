package voting;

public class Result {
		
		    private int candidateA;
		    private int candidateB;
		    private int candidateC;

		    public Result() {
		        candidateA = 0;
		        candidateB = 0;
		        candidateC = 0;
		    }

		    public void addVote(int candidate) {
		        switch (candidate) {
		            case 1:
		                candidateA++;
		                break;
		            case 2:
		                candidateB++;
		                break;
		            case 3:
		                candidateC++;
		                break;
		        }
		    }

		    public void displayResults() {
		        System.out.println("\nElection Results:");
		        System.out.println("\nCandidate A: " + candidateA + " votes");
		        System.out.println("Candidate B: " + candidateB + " votes");
		        System.out.println("Candidate C: " + candidateC + " votes\n");
		        
		        if(candidateA>candidateB && candidateA>candidateC)
		        {
		        	System.out.println("\nA is win!!!\n");
		        }
		        else if(candidateB>candidateA && candidateB>candidateC)
		        {
		        	System.out.println("\nB is win!!!\n");
		        }
		        else if(candidateC>candidateA && candidateC>candidateB)
		        {
		        	System.out.println("\nB is win!!!\n");
		        }
		        else if(candidateA==0 && candidateB==0 && candidateC==0)
		        {
		        	System.out.println("\nVote is not taken......\n");
		        }
		        else 
		        {
		        	System.out.println("Draw\n");
		        }
		        
		        
		    }
		

	}


