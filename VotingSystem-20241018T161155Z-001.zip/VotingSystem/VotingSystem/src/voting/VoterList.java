package voting;



	import java.util.ArrayList;

	public class VoterList {
		private ArrayList<User> voterList = new ArrayList<>();

		public ArrayList<User> getVoterList() {
			return voterList;
		}

		public void setVoterList(User voterList) {
			this.voterList.add(voterList);
		}
		
		public void totalVoter() {
			System.out.println("Total Voter: "+ this.voterList.size());
		}
		
		public User findUser(String nid) {
			for(int i = 0;i<this.voterList.size();i++) {
				User u = this.voterList.get(i);
				if(nid.compareToIgnoreCase(u.getnid()) == 0) 
					return u;
			}
			return null;
		}
		
	}


